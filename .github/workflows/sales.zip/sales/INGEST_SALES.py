# Databricks notebook source
from pyspark.sql.functions import *
from pyspark.sql.types import StructType, StructField, StringType, IntegerType, DoubleType
from pyspark.sql.functions import month, col

# COMMAND ----------

dbutils.widgets.removeAll()

# COMMAND ----------

dbutils.widgets.text("storage_name", "dev1storageforsales")
dbutils.widgets.text("container", "sales")
dbutils.widgets.text("catalogo", "dev1workspace")
dbutils.widgets.text("esquema", "bronze")




# COMMAND ----------

storage_name = dbutils.widgets.get("storage_name")
container = dbutils.widgets.get("container")
catalogo = dbutils.widgets.get("catalogo")
esquema = dbutils.widgets.get("esquema")


# COMMAND ----------

ruta = f"abfss://{container}@{storage_name}.dfs.core.windows.net/sales_dataset_1000.csv"

# COMMAND ----------

df_sales = spark.read.option('header', True)\
                        .option('inferSchema', True)\
                        .csv(ruta)
df_sales.display()

# COMMAND ----------

sales_schema = StructType([
	StructField("transaction_id", StringType(), False),
    StructField("customer_id", StringType(), False),
    StructField("product_id", StringType(), False),
    StructField("sale_date", StringType(), False),
    StructField("amount", DoubleType(), False),
    StructField("quantity", IntegerType(), False)
])
spark.createDataFrame([], sales_schema).printSchema()

# COMMAND ----------

df_sales_final = spark.read\
.option('header', True)\
.schema(sales_schema)\
.csv(ruta)

# COMMAND ----------

df_sales_final.write.mode('overwrite').partitionBy('product_id').saveAsTable(f'{catalogo}.{esquema}.sales_bronze')
sales_df = spark.sql(f"SELECT * FROM {catalogo}.{esquema}.sales_bronze")
sales_df.display()