# Databricks notebook source
from pyspark.sql.functions import *
from pyspark.sql.types import StructType, StructField, StringType, IntegerType, DoubleType
from pyspark.sql.functions import month, col


# COMMAND ----------

dbutils.widgets.removeAll()

# COMMAND ----------

dbutils.widgets.text("storage_name", "dev1storageforsales")
dbutils.widgets.text("container", "sales")
dbutils.widgets.text("catalogo", "dev1workspace")
dbutils.widgets.text("esquema", "bronze")

# COMMAND ----------

storage_name = dbutils.widgets.get("storage_name")
container = dbutils.widgets.get("container")
catalogo = dbutils.widgets.get("catalogo")
esquema = dbutils.widgets.get("esquema")


# COMMAND ----------

ruta = f"abfss://{container}@{storage_name}.dfs.core.windows.net/customers_dataset_50.csv"

# COMMAND ----------

customers_schema = StructType([
	StructField("customer_id", StringType(), False),
    StructField("acquisition_date", StringType(), False),
    StructField("acquisition_channel", StringType(), False)
])
spark.createDataFrame([], customers_schema).printSchema()

# COMMAND ----------

df_customers_final = spark.read\
.option('header', True)\
.schema(customers_schema)\
.csv(ruta)

# COMMAND ----------

df_customers_final.write.mode('overwrite').partitionBy('customer_id').saveAsTable(f'{catalogo}.{esquema}.customers_bronze')
customers_df = spark.sql(f"SELECT * FROM {catalogo}.{esquema}.customers_bronze")
customers_df.display()