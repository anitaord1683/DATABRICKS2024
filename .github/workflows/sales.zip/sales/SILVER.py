# Databricks notebook source
# MAGIC %md
# MAGIC SILVER

# COMMAND ----------

from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql import functions as F
from pyspark.sql import Window
from pyspark.sql.functions import col, sum, lag, month

# COMMAND ----------

dbutils.widgets.removeAll()

# COMMAND ----------

dbutils.widgets.text("catalogo", "dev1workspace")
dbutils.widgets.text("esquema_source", "bronze")
dbutils.widgets.text("esquema_sink", "silver")
dbutils.widgets.text("storage_name", "dev1storageforsales")
dbutils.widgets.text("container", "sales")


# COMMAND ----------

storage_name = dbutils.widgets.get("storage_name")
container = dbutils.widgets.get("container")
catalogo = dbutils.widgets.get("catalogo")
esquema_source = dbutils.widgets.get("esquema_source")
esquema_sink = dbutils.widgets.get("esquema_sink")

# COMMAND ----------

df_sales_silver = spark.table(f"{catalogo}.{esquema_source}.sales_bronze")
df_sales_silver_updated = df_sales_silver.withColumn("sale_date", F.to_timestamp("sale_date", "yyyy-MM-dd HH:mm:ss"))
df_sales_silver_updated.write.mode('overwrite').partitionBy('product_id').saveAsTable(f'{catalogo}.{esquema_sink}.sales_silver')
df_sales_silver.display()

# COMMAND ----------

df_with_month = df_sales_silver.withColumn(
    "month", 
    month(col("sale_date"))
)

# COMMAND ----------

window_spec = Window.partitionBy(col("product_id")).orderBy(col("month"))

df_aggregated_sales = df_with_month.groupBy("month", "product_id").agg(
    sum("amount").alias("current_month_sales")
)

# COMMAND ----------

df_sales_by_product = df_aggregated_sales.withColumn(
    "previous_month_sales", 
    lag(col("current_month_sales"), 1).over(window_spec)
)

# COMMAND ----------

df_sales_by_product.write.mode('overwrite').partitionBy('product_id').saveAsTable(f'{catalogo}.{esquema_sink}.sales_by_product')
df_sales_by_product.show()

# COMMAND ----------

df_customers_silver = spark.table(f"{catalogo}.{esquema_source}.customers_bronze")
df_customers_silver_updated = df_customers_silver.withColumn("acquisition_date", F.to_timestamp("acquisition_date", "yyyy-MM-dd HH:mm:ss"))
df_customers_silver_updated.write.mode('overwrite').partitionBy('customer_id').saveAsTable(f'{catalogo}.{esquema_sink}.customers_silver')
df_customers_silver_updated.show()

# COMMAND ----------

df_marketing_silver = spark.table(f"{catalogo}.{esquema_source}.marketing_bronze")
df_marketing_silver_updated = df_marketing_silver.withColumn("date", F.to_timestamp("date", "yyyy-MM-dd HH:mm:ss"))
df_marketing_silver_updated.write.mode('overwrite').partitionBy('channel_id').saveAsTable(f'{catalogo}.{esquema_sink}.marketing_silver')
df_marketing_silver_updated.show()

# COMMAND ----------

df_product_costs_silver = spark.table(f"{catalogo}.{esquema_source}.product_costs_bronze")
df_product_costs_silver_updated = df_product_costs_silver.write.mode('overwrite').partitionBy('product_id').saveAsTable(f'{catalogo}.{esquema_sink}.product_costs_silver')
display(df_product_costs_silver_updated)

# COMMAND ----------

df_products_silver = spark.table(f"{catalogo}.{esquema_source}.products_bronze")
df_products_silver_updated = df_products_silver.write.mode('overwrite').partitionBy('product_id').saveAsTable(f'{catalogo}.{esquema_sink}.products_silver')
display(df_products_silver_updated)

# COMMAND ----------

df_sales_silver = spark.table(f"{catalogo}.{esquema_source}.sales_bronze")
df_sales_silver_updated = df_sales_silver.withColumn("sale_date", F.to_timestamp("sale_date", "yyyy-MM-dd HH:mm:ss"))
df_sales_silver_updated.write.mode('overwrite').partitionBy('product_id').saveAsTable(f'{catalogo}.{esquema_sink}.sales_silver')
display(df_sales_silver_updated)