# Databricks notebook source
from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql import functions as F
from pyspark.sql import Window
from pyspark.sql.functions import col, sum, lag, month


# COMMAND ----------

dbutils.widgets.text("storage_name", "dev1storageforsales")
dbutils.widgets.text("container", "sales")
dbutils.widgets.text("catalogo", "dev1workspace")
dbutils.widgets.text("esquema_source", "silver")
dbutils.widgets.text("esquema_sink", "golden")


# COMMAND ----------

storage_name = dbutils.widgets.get("storage_name")
container = dbutils.widgets.get("container")
catalogo = dbutils.widgets.get("catalogo")
esquema_source = dbutils.widgets.get("esquema_source")
esquema_sink = dbutils.widgets.get("esquema_sink")

# COMMAND ----------

df_sales_golden = spark.table(f"{catalogo}.{esquema_source}.sales_by_product")
df_sales_golden.display()

# COMMAND ----------

df_gold_sales_growth = df_sales_golden.withColumn(
    "growth_rate",
    (F.col("current_month_sales") - F.col("previous_month_sales")) / F.col("previous_month_sales")
).select(
    "month",
    "product_id",
    "previous_month_sales",
    "current_month_sales",
    "growth_rate"
)
df_gold_sales_growth.display()

# COMMAND ----------

df_gold_sales_growth.write.mode('overwrite').partitionBy('product_id').saveAsTable(f'{catalogo}.{esquema_sink}.sales_growth')

# COMMAND ----------

df_sales_silver = spark.table(f"{catalogo}.{esquema_source}.sales_silver")
df_product_costs_silver = spark.table(f"{catalogo}.{esquema_source}.product_costs_silver")
df_gold_avg_profit_margin = (
    df_sales_silver.alias("ss")
    .join(
        df_product_costs_silver.alias("sc"),
        F.col("ss.product_id") == F.col("sc.product_id"),
        "inner"
    )
    .groupBy("ss.product_id")
    .agg(
        (
            (F.sum("amount") - F.sum("cost_of_goods_sold")) / F.sum("amount")
        ).alias("avg_profit_margin")
    )
)

# COMMAND ----------

df_gold_avg_profit_margin.display()
df_gold_avg_profit_margin.write.mode('overwrite').partitionBy('product_id').saveAsTable(f'{catalogo}.{esquema_sink}.gold_avg_profit_margin')

# COMMAND ----------

df_gold_product_performance = (
    df_sales_silver.alias("ss")
    .join(
        df_product_costs_silver.alias("sc"),
        F.col("ss.product_id") == F.col("sc.product_id"),
        "inner"
    )
    .groupBy("ss.product_id")
    .agg(
        F.sum("amount").alias("total_sales"),
        (
            (F.sum("amount") - F.sum("cost_of_goods_sold")) / F.sum("amount")
        ).alias("total_profit_margin")
    )
)
df_gold_product_performance.display()
df_gold_product_performance.write.mode('overwrite').partitionBy('product_id').saveAsTable(f'{catalogo}.{esquema_sink}.gold_product_performance')

# COMMAND ----------

df_marketing_silver = spark.table(f"{catalogo}.{esquema_source}.marketing_silver")
df_customers_silver = spark.table(f"{catalogo}.{esquema_source}.customers_silver")
df_gold_customer_acquisition_cost = (
    df_marketing_silver.alias("bm")
    .join(
        df_customers_silver.alias("bc"),
        F.col("bm.date") >= F.col("bc.acquisition_date"),
        "inner"
    )
    .groupBy("bm.channel_id")
    .agg(
        F.sum("marketing_spend").alias("total_marketing_spend"),
        F.countDistinct("customer_id").alias("new_customers")
    )
    .withColumn(
        "acquisition_cost",
        F.col("total_marketing_spend") / F.col("new_customers")
    )
)
df_gold_customer_acquisition_cost.display()
df_gold_customer_acquisition_cost.write.mode('overwrite').partitionBy('channel_id').saveAsTable(f'{catalogo}.{esquema_sink}.gold_customer_acquisition_cost')