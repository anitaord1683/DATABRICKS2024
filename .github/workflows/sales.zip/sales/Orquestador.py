# Databricks notebook source
dbutils.notebook.run("/Workspace/Users/developer1@anadeyanirahotmail.onmicrosoft.com/sales/CUSTOMER_INGEST",3600,{"storage_name":"dev1storageforsales"})

# COMMAND ----------

dbutils.notebook.run("/Workspace/Users/developer1@anadeyanirahotmail.onmicrosoft.com/sales/INGEST_MARKETING",3600,{"storage_name":"dev1storageforsales"})

# COMMAND ----------

dbutils.notebook.run("/Workspace/Users/developer1@anadeyanirahotmail.onmicrosoft.com/sales/INGEST_PRODUCTS",3600,{"storage_name":"dev1storageforsales"})

# COMMAND ----------

dbutils.notebook.run("/Workspace/Users/developer1@anadeyanirahotmail.onmicrosoft.com/sales/INGEST_SALES",3600,{"storage_name":"dev1storageforsales"})

# COMMAND ----------

dbutils.notebook.run("/Workspace/Users/developer1@anadeyanirahotmail.onmicrosoft.com/sales/PRODUCT_COSTS_INGESTION",3600,{"storage_name":"dev1storageforsales"})

# COMMAND ----------

dbutils.notebook.run("/Workspace/Users/developer1@anadeyanirahotmail.onmicrosoft.com/sales/SILVER",3600,{"storage_name":"dev1storageforsales","container":"sales","catalogo":"dev1workspace","esquema_source":"bronze","esquema_sink":"silver"})

# COMMAND ----------

dbutils.notebook.run("/Workspace/Users/developer1@anadeyanirahotmail.onmicrosoft.com/sales/GOLDEN",3600,{"storage_name":"dev1storageforsales","container":"sales","catalogo":"dev1workspace","esquema_source":"golden","esquema_sink":"golden"})