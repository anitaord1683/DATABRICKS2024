# Databricks notebook source
import getpass

# COMMAND ----------

dbutils.widgets.removeAll()

# COMMAND ----------

dbutils.widgets.text("storage-account", "dev1storageforsales")

# COMMAND ----------

storage_account = dbutils.widgets.get("storage-account")
bronze = "bronze"
silver = "silver"
golden = "golden"

scope = "accessScopeforADLS"
key = "storageAccessKey"

# COMMAND ----------

jdbcHostname            = dbutils.secrets.get(scope="accessScopeforADLS", key="databricks-jdbcHostname")
jdbcDatabase            = dbutils.secrets.get(scope="accessScopeforADLS", key="databricks-jdbcDatabase")
jdbcPort        = dbutils.secrets.get(scope="accessScopeforADLS", key="databricks-jdbcPort")
jdbcUsername        = dbutils.secrets.get(scope="accessScopeforADLS", key="databricks-jdbcUsername")
jdbcPassword        = dbutils.secrets.get(scope="accessScopeforADLS", key="databricks-jdbcPassword")

# COMMAND ----------

# URL JDBC
jdbcUrl = f"jdbc:sqlserver://{jdbcHostname}:{jdbcPort};database={jdbcDatabase};encrypt=true;trustServerCertificate=false;hostNameInCertificate=*.database.windows.net;loginTimeout=30;"

# COMMAND ----------

df_sales_updated = spark.table(f"golden.sales_growth")

# COMMAND ----------

df_sales_updated.write.format("jdbc") \
    .option("url", jdbcUrl) \
    .option("dbtable", "test_table") \
    .option("user", jdbcUsername) \
    .option("password", jdbcPassword) \
    .mode("overwrite") \
    .save()

# COMMAND ----------

df_sales_updated.display()

# COMMAND ----------

