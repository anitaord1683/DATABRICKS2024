# Databricks notebook source
from pyspark.sql.functions import *
from pyspark.sql.types import StructType, StructField, StringType, IntegerType, DoubleType
from pyspark.sql.functions import month, col

# COMMAND ----------

dbutils.widgets.removeAll()

# COMMAND ----------

dbutils.widgets.text("storage_name", "dev1storageforsales")
dbutils.widgets.text("container", "sales")
dbutils.widgets.text("catalogo", "dev1workspace")
dbutils.widgets.text("esquema", "bronze")

# COMMAND ----------

storage_name = dbutils.widgets.get("storage_name")
container = dbutils.widgets.get("container")
catalogo = dbutils.widgets.get("catalogo")
esquema = dbutils.widgets.get("esquema")

# COMMAND ----------

ruta = f"abfss://{container}@{storage_name}.dfs.core.windows.net/product_costs_dataset_50.csv"

# COMMAND ----------

product_costs_schema = StructType([
	StructField("product_id", StringType(), False),
    StructField("cost_of_goods_sold", DoubleType(), False),
    StructField("other_costs", DoubleType(), False)
])
spark.createDataFrame([], product_costs_schema).printSchema()

# COMMAND ----------

df_product_costs_final = spark.read\
.option('header', True)\
.schema(product_costs_schema)\
.csv(ruta)

# COMMAND ----------

df_product_costs_final.write.mode('overwrite').partitionBy('product_id').saveAsTable(f'{catalogo}.{esquema}.product_costs_bronze')
product_costs_df = spark.sql(f"SELECT * FROM {catalogo}.{esquema}.product_costs_bronze")
product_costs_df.display()